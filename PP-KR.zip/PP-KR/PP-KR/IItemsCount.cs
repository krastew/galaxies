﻿using System;
namespace PP_KR
{
    public interface IItemsCount
    {
        public void totalItems();
    }
}
